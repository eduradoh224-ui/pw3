function toggle() {
    const container = document.getElementById("container");
    container.classList.toggle("active");
}

// LOGIN
document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("loginEmail").value;
    const senha = document.getElementById("loginSenha").value;

    alert(
        "LOGIN REALIZADO!\n\n" +
        "Email: " + email + "\n" +
        "Senha: " + senha
    );
});

// CADASTRO
document.getElementById("registerForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const nome = document.getElementById("cadNome").value;
    const email = document.getElementById("cadEmail").value;
    const senha = document.getElementById("cadSenha").value;

    alert(
        "CADASTRO REALIZADO!\n\n" +
        "Nome: " + nome + "\n" +
        "Email: " + email + "\n" +
        "Senha: " + senha
    );
});